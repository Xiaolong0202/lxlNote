package com.itheima.dao.impl;

import com.itheima.dao.PersonDao;



public class PersonDaoImpl implements PersonDao {
}
