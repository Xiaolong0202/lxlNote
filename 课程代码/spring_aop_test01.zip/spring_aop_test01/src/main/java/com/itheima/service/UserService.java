package com.itheima.service;

public interface UserService {

    void show1();

    void show2();

}
