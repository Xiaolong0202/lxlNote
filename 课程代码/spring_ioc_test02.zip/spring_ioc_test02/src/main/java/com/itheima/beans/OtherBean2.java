package com.itheima.beans;

public class OtherBean2 {
}
